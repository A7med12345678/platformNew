@extends('layouts.adminApp')
@section('title', 'Admin Manager : ' . $Global_platFormName)
@section('styles')
    <link href="{{ asset('admin-css/adminManager-part.css') }}" rel="stylesheet">
@endsection

@section('content')
    <!-- Content Start -->
    <div class="container">
        <div class="container pt-5">

            @include('components.flashMsg')

            <h1 class="text-primary ">Admin Remove</h1>

            <form id="upload-form" action="{{ route('admin/deleteAdmin') }}" method="POST" class="form-inline">
                @csrf
                <div class="form-group mx-sm-3 m-3">
                    <label for="id" class="sr-only">ID</label>
                    <input type="text" class="form-control" id="id" name="admin_id" placeholder="Enter ID">
                </div>

                <button type="submit" class="btn btn-primary mb-2">Remove</button>
            </form>


            <hr class="m-5">

            <h1 class="text-primary  mt-5">Admin List</h1>
            <div class="table-responsive">
                <table class="table table-bordered mt-3">
                    <thead>
                        <tr>
                            <th>Admin ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <!-- Add more columns based on your User model properties -->
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($admins as $admin)
                            <tr>
                                <td class="text-danger font-weight-bold">{{ $admin->id }}</td>
                                <td>{{ $admin->name }}</td>
                                <td>{{ $admin->email }}</td>
                                <td>{{ $admin->phone }}</td>
                                <!-- Add more columns based on your User model properties -->
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>


        </div>
    </div>



@endsection
