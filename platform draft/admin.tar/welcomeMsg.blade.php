@extends('layouts.adminApp')
@section('title', 'Welcome Msg : ' . $Global_platFormName)
@section('styles')
    <link href="{{ asset('admin-css/payment-part.css') }}" rel="stylesheet">
@endsection

@section('content')

    <!-- Content Start -->

    <div class="container p-4">
        {{-- session return: --}}
        @if (session('flash_msg'))
            <div class="alert alert-success m-4">
                {{ session('flash_msg') }}
            </div>
        @endif
        {{--             
            <h1>Edit Messages :</h1>
            <form action="{{ route('updateMsg') }}" method="POST" class="mb-5">
                @csrf
                <div class="mb-3">
                    <label for="message1" class="form-label">Title :</label>
                    <input type="text" class="form-control" id="message1" name="message1">
                </div>
                <div class="mb-3">
                    <label for="message2" class="form-label">Content :</label>
                    <input type="text" class="form-control" id="message2" name="message2">
                </div>
                <button type="submit" class="btn btn-primary"  onclick="return confirm('Are you sure you want to save changes?')">Save Changes</button>
            </form>

            <hr>

            <h1>Honour Messages :</h1>
            <form action="{{ route('honourMsg') }}" method="POST" class="mb-5" enctype="multipart/form-data">
                @csrf
                <div class="mb-3">
                    <label for="name" class="form-label">Name:</label>
                    <input type="text" class="form-control" id="name" name="name">
                </div>
                <div class="mb-3">
                    <label for="name" class="form-label">Faculty :</label>
                    <input type="text" class="form-control" id="name" name="faculty">
                </div>
                <div class="mb-3">
                    <label for="name" class="form-label">Year :</label>
                    <input type="text" class="form-control" id="name" name="year">
                </div>
                <div class="mb-3">
                    <label for="honour_photo" class="form-label">Photo:</span></label>
                    <input type="file" class="form-control" id="honour_photo" name="image">
                </div>
                <button type="submit" class="btn btn-primary"  onclick="return confirm('Are you sure you want to save changes?')">Save Changes</button>
            </form>
            
            <hr> --}}


        {{-- <h2>Add Free Content</h2> --}}
        <h1 class="pb-5"> Free Content Manager : </h1>


        <h3>Add video : </h3>
        <form method="POST" action="{{ route('freeCon') }}">
            @csrf <!-- Laravel CSRF protection token -->

            <div class="mb-3">
                <label for="new_url" class="form-label">New URL</label>
                <input type="text" class="form-control" id="new_url" name="new_url" required>
            </div>

            <button type="submit" class="btn btn-primary"
                onclick="return confirm('Are you sure you want to upload and save changes?')">Add</button>
        </form>

        <hr>

        <h3>Delete Video : </h3>
        <form method="POST" action="{{ route('delfreeCon') }}">
            @csrf <!-- Laravel CSRF protection token -->

            <div class="mb-3">
                <label for="url_to_delete" class="form-label">Url to delete : </label>
                <input type="text" class="form-control" id="url_to_delete" name="url_to_delete" required>
            </div>

            <button type="submit" class="btn btn-primary"
                onclick="return confirm('Are you sure you want to upload and save changes?')">remove</button>
        </form>

        <hr>

        {{-- <h1>Free Content :</h1>
        <form action="{{ route('freeCon') }}" method="POST" class="mb-5" enctype="multipart/form-data">
            @csrf
            <div class="mb-3 mt-4">
                <label for="title1" class="form-label">Free Lec Title :</label>
                <input type="text" class="form-control" id="title1" name="free_title1" value"كما هي">
            </div>
            <div class="mb-3">
                <label for="title2" class="form-label">Free Exercise Title :</label>
                <input type="text" class="form-control" id="title2" name="free_title2" value"كما هي">
            </div>


            <!--<div class="mb-3">-->
            <!--    <label for="video" class="form-label">Free Video:<span class="font-weight-bold text-danger">(free.mp4)</span></label>-->
            <!--    <input type="file" class="form-control" id="video" name="free_video">-->
            <!--</div>-->
            <div class="mb-3">
                <label for="free_pdf" class="form-label">Free Pdf:</label>
                <input type="file" class="form-control" id="free_pdf" name="free_pdf" accept=".pdf">
            </div>
            <button type="submit" class="btn btn-primary"
                onclick="return confirm('Are you sure you want to upload and save changes?')">Upload</button>
        </form> --}}


    </div>

@endsection
