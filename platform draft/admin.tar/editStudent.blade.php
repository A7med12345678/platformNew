@extends('layouts.adminApp')
@section('title', 'Edit (' . $user->id . ') : ' . $Global_platFormName)

@section('content')


        <div class="p-5">
            <div class="h1 m-3">Edit Student :</div>

            <form action="{{ route('Admin.update', $user->id) }}" class="" method="post">
                {!! csrf_field() !!}
                @method('PATCH')
                <input type="text" name="name" id="name" value="{{ $user->name }}"
                    class="form-control"></br>
                <label>Mobile</label></br>
                <input type="text" name="phone" id="address" value="{{ $user->phone }}"
                    class="form-control"></br>
                <label>Parent Mobile</label></br>
                <input type="text" name="parent_phone" id="mobile" value="{{ $user->parent_phone }}"
                    class="form-control"></br>
                <label>Whatssapp</label></br>
                <input type="text" name="whatsapp" id="whatsapp" value="{{ $user->whatsapp }}"
                    class="form-control"></br>
                <label>Grade</label></br>
                <input type="text" name="grade" id="grade" value="{{ $user->grade }}"
                    class="form-control"></br>
                <label>Code</label></br>
                <input type="text" name="center_code" id="center_code" value="{{ $user->center_code }}"
                    class="form-control"></br>
                <label for="learn_type">Type</label><br>
                <select id="learn_type" class="form-control" name="learn_type" required>
                    <option value="عام" {{ $user->learn_type === 'عام' ? 'selected' : '' }}>عام</option>
                    <option value="أزهر" {{ $user->learn_type === 'أزهر' ? 'selected' : '' }}>أزهر</option>
                </select><br>
                <label>Email</label></br>
                <input type="text" name="email" id="mobile" value="{{ $user->email }}"
                    class="form-control"></br>
                <label class="text-danger">Password</label></br>
                <input type="text" name="password" id="password" value="{{ $user->password }}"
                    class="form-control"></br>
                <input type="submit" value="Update" class="btn btn-success"></br>
            </form>
        </div>
        
        

@endsection